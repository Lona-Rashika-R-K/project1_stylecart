"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";
import { getProducts } from "@/lib/catalog";
import type { Product } from "@/lib/types";
import { ProductCard } from "@/components/ProductCard";
import { ProductFilters } from "@/components/ProductFilters";

function ProductsContent() {
  const params = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [filters, setFilters] = useState({
    search: params.get("q") ?? "",
    category: params.get("category") ?? "",
    size: "",
    color: "",
    stock: "",
    sort: "newest",
    maxPrice: ""
  });

  useEffect(() => {
    getProducts().then(setProducts);
  }, []);

  const filtered = useMemo(() => {
    const next = products
      .filter((product) => product.name.toLowerCase().includes(filters.search.toLowerCase()))
      .filter((product) => !filters.category || product.category === filters.category)
      .filter((product) => !filters.size || product.sizes.includes(filters.size))
      .filter((product) => !filters.color || product.colors.includes(filters.color))
      .filter((product) => !filters.maxPrice || product.discountPrice <= Number(filters.maxPrice))
      .filter((product) => !filters.stock || (filters.stock === "in" ? product.stock > 0 : product.stock < 1));

    if (filters.sort === "price-asc") next.sort((a, b) => a.discountPrice - b.discountPrice);
    if (filters.sort === "price-desc") next.sort((a, b) => b.discountPrice - a.discountPrice);
    if (filters.sort === "popular") next.sort((a, b) => Number(Boolean(b.popular)) - Number(Boolean(a.popular)));
    return next;
  }, [filters, products]);

  return (
    <main className="page-shell entrance">
      <div className="mb-6">
        <p className="font-bold uppercase tracking-wide text-clay">Catalog</p>
        <h1 className="section-title">Product Listing</h1>
      </div>
      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <ProductFilters filters={filters} onChange={(name, value) => setFilters((current) => ({ ...current, [name]: value }))} />
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </main>
  );
}

export default function ProductsPage() {
  return (
    <Suspense fallback={<main className="page-shell">Loading products...</main>}>
      <ProductsContent />
    </Suspense>
  );
}
