import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { db, storage } from "@/lib/firebase";
import { fallbackProducts } from "@/lib/constants";
import type { Product } from "@/lib/types";

const productsRef = collection(db, "products");

export async function getProducts(): Promise<Product[]> {
  try {
    const snapshot = await getDocs(query(productsRef, orderBy("createdAt", "desc")));
    const products = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }) as Product);
    return products.length ? products : fallbackProducts;
  } catch {
    return fallbackProducts;
  }
}

export async function getFeaturedProducts(): Promise<Product[]> {
  try {
    const snapshot = await getDocs(query(productsRef, where("featured", "==", true), limit(8)));
    const products = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }) as Product);
    return products.length ? products : fallbackProducts.filter((product) => product.featured);
  } catch {
    return fallbackProducts.filter((product) => product.featured);
  }
}

export async function getProduct(id: string): Promise<Product | null> {
  try {
    const snapshot = await getDoc(doc(db, "products", id));
    if (snapshot.exists()) return { id: snapshot.id, ...snapshot.data() } as Product;
    return fallbackProducts.find((product) => product.id === id) ?? null;
  } catch {
    return fallbackProducts.find((product) => product.id === id) ?? null;
  }
}

export async function saveProduct(product: Omit<Product, "id">, id?: string) {
  const payload = { ...product, createdAt: product.createdAt ?? serverTimestamp() };
  if (id) {
    await updateDoc(doc(db, "products", id), payload);
    return id;
  }
  const created = await addDoc(productsRef, payload);
  return created.id;
}

export async function removeProduct(id: string) {
  await deleteDoc(doc(db, "products", id));
}

export async function uploadProductImage(file: File) {
  const fileRef = ref(storage, `products/${Date.now()}-${file.name}`);
  await uploadBytes(fileRef, file);
  return getDownloadURL(fileRef);
}
