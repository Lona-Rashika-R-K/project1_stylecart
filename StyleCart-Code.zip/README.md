# StyleCart

StyleCart is a responsive Next.js clothing store backed by Firebase Authentication, Firestore, and Firebase Storage. It includes customer login/signup, catalog browsing, filters, cart, coupon checkout, order confirmation, profile management, wishlist, tracking, and an admin dashboard for product and order management.

## Tech Stack

- Next.js App Router + React + TypeScript
- Tailwind CSS with smooth transitions and responsive layouts
- Firebase Authentication
- Firestore collections: `users`, `products`, `cart`, `wishlist`, `orders`, `coupons`
- Firebase Storage folders: `/products`, `/profile-images`, `/categories`

## Setup

1. Install dependencies:

```bash
npm install
```

2. Copy `.env.example` to `.env.local` and fill in your Firebase web app config.

3. Enable Firebase Authentication with Email/Password.

4. Deploy rules:

```bash
firebase deploy --only firestore:rules,storage
```

5. Optional seed data:

```bash
set FIREBASE_SERVICE_ACCOUNT_PATH=./service-account.json
npm run seed
```

6. Run locally:

```bash
npm run dev
```

Open `http://localhost:3000`. The first page redirects to `/login`.

## Admin Access

Create a user normally, then update that user's Firestore document in `users/{uid}`:

```json
{
  "role": "admin"
}
```

Admin users are redirected to `/admin` after login and can create, edit, delete, upload images, manage stock, and update order statuses.

## Project Structure

```text
src/app                 Next.js routes
src/components          Shared UI components
src/contexts            Auth and cart providers
src/lib                 Firebase, catalog, orders, constants, types
scripts/seed-products.mjs
firestore.rules
storage.rules
```

## MVP Coverage

- Login, signup, password reset
- Home, product listing, product detail
- Cart, coupons, checkout, stock reduction, confirmation
- Profile, profile image upload, order history
- Wishlist and order tracking
- Admin product management and order status updates
- Firestore and Storage security rules

## Notes

The catalog includes local fallback products so the UI is usable before Firestore is seeded. Once Firebase is configured and products exist, Firestore data is used automatically.
