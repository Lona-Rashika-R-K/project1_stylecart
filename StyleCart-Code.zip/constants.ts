import type { Product } from "@/lib/types";

export const categories = ["Men", "Women", "Kids", "Shoes", "Accessories", "New Arrivals", "Sale"];
export const sizes = ["XS", "S", "M", "L", "XL", "XXL"];
export const colors = ["Black", "White", "Blue", "Green", "Red", "Tan"];

export const fallbackProducts: Product[] = [
  {
    id: "denim-jacket",
    name: "Denim Utility Jacket",
    description: "Structured denim jacket with roomy pockets, contrast stitching, and an easy everyday fit.",
    category: "Women",
    price: 2499,
    discountPrice: 1999,
    sizes: ["S", "M", "L", "XL"],
    colors: ["Blue", "Black"],
    stock: 20,
    images: ["https://images.unsplash.com/photo-1543076447-215ad9ba6923?auto=format&fit=crop&w=900&q=80"],
    featured: true,
    popular: true
  },
  {
    id: "linen-shirt",
    name: "Linen Camp Shirt",
    description: "Breathable linen blend shirt with a relaxed collar and soft garment-washed handfeel.",
    category: "Men",
    price: 1899,
    discountPrice: 1499,
    sizes: ["M", "L", "XL"],
    colors: ["White", "Tan", "Green"],
    stock: 14,
    images: ["https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=900&q=80"],
    featured: true
  },
  {
    id: "kids-hoodie",
    name: "Kids Everyday Hoodie",
    description: "Soft fleece hoodie with ribbed cuffs, kangaroo pocket, and durable school-day stitching.",
    category: "Kids",
    price: 1299,
    discountPrice: 999,
    sizes: ["XS", "S", "M"],
    colors: ["Red", "Blue"],
    stock: 8,
    images: ["https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&w=900&q=80"],
    featured: false,
    popular: true
  },
  {
    id: "runner-sneaker",
    name: "Runner Knit Sneaker",
    description: "Lightweight knit sneaker with cushioned sole and clean styling for daily movement.",
    category: "Shoes",
    price: 3299,
    discountPrice: 2799,
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "White"],
    stock: 5,
    images: ["https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80"],
    featured: true
  },
  {
    id: "canvas-tote",
    name: "Canvas Market Tote",
    description: "Heavy canvas tote with reinforced handles and enough space for daily essentials.",
    category: "Accessories",
    price: 899,
    discountPrice: 699,
    sizes: ["M"],
    colors: ["Tan", "Black"],
    stock: 0,
    images: ["https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=80"],
    featured: false
  },
  {
    id: "sale-dress",
    name: "Pleated Midi Dress",
    description: "Fluid midi dress with subtle pleats, side pockets, and a polished weekend silhouette.",
    category: "Sale",
    price: 2999,
    discountPrice: 1899,
    sizes: ["S", "M", "L"],
    colors: ["Green", "Black"],
    stock: 3,
    images: ["https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=80"],
    featured: true,
    popular: true
  }
];

export const statusSteps = ["Order Placed", "Processing", "Shipped", "Out for Delivery", "Delivered"];
