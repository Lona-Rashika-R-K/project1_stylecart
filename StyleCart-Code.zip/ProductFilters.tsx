"use client";

import { SlidersHorizontal } from "lucide-react";
import { categories, colors, sizes } from "@/lib/constants";

type Props = {
  filters: {
    search: string;
    category: string;
    size: string;
    color: string;
    stock: string;
    sort: string;
    maxPrice: string;
  };
  onChange: (name: string, value: string) => void;
};

export function ProductFilters({ filters, onChange }: Props) {
  return (
    <aside className="space-y-4 rounded-lg border border-black/10 bg-white p-4">
      <div className="flex items-center gap-2 font-bold">
        <SlidersHorizontal size={18} />
        Filters
      </div>
      <input className="input" placeholder="Search products" value={filters.search} onChange={(event) => onChange("search", event.target.value)} />
      <select className="input" value={filters.category} onChange={(event) => onChange("category", event.target.value)}>
        <option value="">All categories</option>
        {categories.map((category) => (
          <option key={category}>{category}</option>
        ))}
      </select>
      <select className="input" value={filters.size} onChange={(event) => onChange("size", event.target.value)}>
        <option value="">All sizes</option>
        {sizes.map((size) => (
          <option key={size}>{size}</option>
        ))}
      </select>
      <select className="input" value={filters.color} onChange={(event) => onChange("color", event.target.value)}>
        <option value="">All colors</option>
        {colors.map((color) => (
          <option key={color}>{color}</option>
        ))}
      </select>
      <input className="input" type="number" placeholder="Max price" value={filters.maxPrice} onChange={(event) => onChange("maxPrice", event.target.value)} />
      <select className="input" value={filters.stock} onChange={(event) => onChange("stock", event.target.value)}>
        <option value="">Any stock</option>
        <option value="in">In stock</option>
        <option value="out">Out of stock</option>
      </select>
      <select className="input" value={filters.sort} onChange={(event) => onChange("sort", event.target.value)}>
        <option value="newest">Newest first</option>
        <option value="price-asc">Price low to high</option>
        <option value="price-desc">Price high to low</option>
        <option value="popular">Popular products</option>
      </select>
    </aside>
  );
}
