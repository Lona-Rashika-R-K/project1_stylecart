import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  increment,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { CartItem, Coupon, Order, OrderStatus, ShippingDetails } from "@/lib/types";

export function calculateTotals(items: CartItem[], coupon?: Coupon | null) {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const eligible = coupon?.active && subtotal >= coupon.minimumOrderAmount;
  const discount = eligible
    ? coupon.discountType === "percentage"
      ? Math.round((subtotal * coupon.discountValue) / 100)
      : coupon.discountValue
    : 0;
  const deliveryCharge = subtotal > 2500 || subtotal === 0 ? 0 : 50;
  return { subtotal, discount, deliveryCharge, totalAmount: Math.max(subtotal - discount + deliveryCharge, 0) };
}

export async function findCoupon(code: string) {
  const normalized = code.trim().toUpperCase();
  if (!normalized) return null;
  const snapshot = await getDocs(query(collection(db, "coupons"), where("code", "==", normalized)));
  if (snapshot.empty) return null;
  return snapshot.docs[0].data() as Coupon;
}

export async function placeOrder(userId: string, items: CartItem[], shippingDetails: ShippingDetails, coupon?: Coupon | null) {
  const totals = calculateTotals(items, coupon);
  return runTransaction(db, async (transaction) => {
    for (const item of items) {
      const productRef = doc(db, "products", item.productId);
      const productSnap = await transaction.get(productRef);
      const currentStock = productSnap.exists() ? Number(productSnap.data().stock ?? 0) : item.stock ?? 0;
      if (currentStock < item.quantity) throw new Error(`${item.name} does not have enough stock.`);
      transaction.update(productRef, { stock: increment(-item.quantity) });
    }

    const orderId = `SC-${Date.now()}`;
    const orderRef = doc(collection(db, "orders"));
    transaction.set(orderRef, {
      orderId,
      userId,
      items,
      shippingDetails,
      paymentMethod: "Cash on Delivery",
      paymentStatus: "Pending",
      orderStatus: "Order Placed",
      ...totals,
      createdAt: serverTimestamp()
    });
    transaction.set(doc(db, "cart", userId), { userId, items: [], updatedAt: serverTimestamp() });
    return { id: orderRef.id, orderId, ...totals };
  });
}

export async function getUserOrders(userId: string): Promise<Order[]> {
  const snapshot = await getDocs(query(collection(db, "orders"), where("userId", "==", userId), orderBy("createdAt", "desc")));
  return snapshot.docs.map((item) => ({ id: item.id, ...item.data() }) as Order);
}

export async function getAllOrders(): Promise<Order[]> {
  const snapshot = await getDocs(query(collection(db, "orders"), orderBy("createdAt", "desc")));
  return snapshot.docs.map((item) => ({ id: item.id, ...item.data() }) as Order);
}

export async function getOrder(idOrOrderId: string): Promise<Order | null> {
  const direct = await getDoc(doc(db, "orders", idOrOrderId));
  if (direct.exists()) return { id: direct.id, ...direct.data() } as Order;

  const snapshot = await getDocs(query(collection(db, "orders"), where("orderId", "==", idOrOrderId)));
  if (snapshot.empty) return null;
  return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Order;
}

export async function updateOrderStatus(id: string, orderStatus: OrderStatus) {
  await updateDoc(doc(db, "orders", id), { orderStatus });
}
